from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('login',views.login_page,name="login"),
    path('logout',views.logout_page,name='logout'),
    path('reg',views.reg,name="reg"),
    path('home',views.home,name="home"),
    path('about',views.about,name="about"),
    path('contact',views.contact,name="contact"),
    path('cart',views.cart,name="cart"),
    path('category',views.category,name="category"),
    path('category/<str:name>',views.collectionview,name="category"),
    path('category/<str:cname>/<str:pname>',views.productdetails,name="productdetails"),
    path('addtocart',views.add_to_cart,name="addtocart"),
    path('remove_cart/<str:cid>',views.remove_cart,name="remove_cart"),
    path('fav',views.fav,name="fav"),
    path('favorite',views.favorite,name="favorite"),
    path('remove_fat/<str:fid>',views.remove_fav,name="remove_fav"),
    path('admin1',views.admin1,name="admin1"),
    path('productform',views.productform,name="productform"),   
    path('update/<int:idd>/',views.update,name="update"),
    path('delete/<int:idd>/',views.delete,name="delete"),
]